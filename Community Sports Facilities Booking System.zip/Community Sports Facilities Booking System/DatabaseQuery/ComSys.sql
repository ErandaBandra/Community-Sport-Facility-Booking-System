CREATE DATABASE ComSportBooking;

USE ComSportBooking;

CREATE TABLE Facility_Type
(
    facility_type_id INT IDENTITY(1,1) NOT NULL,
    type_name VARCHAR(50) NOT NULL,
    description VARCHAR(200),

    CONSTRAINT Facility_Type_PK
        PRIMARY KEY (facility_type_id),

    CONSTRAINT Facility_Type_type_name_UN
        UNIQUE (type_name)
);

CREATE TABLE Member
(
    member_id INT IDENTITY(1,1) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(50) NOT NULL,
    phone VARCHAR(10) NOT NULL,
    address VARCHAR(200),
    city VARCHAR(50) NOT NULL,
    registration_date DATE NOT NULL,

    CONSTRAINT Member_PK
        PRIMARY KEY (member_id),

    CONSTRAINT Member_email_UN
        UNIQUE (email)
);

CREATE TABLE Sport
(
    sport_id INT IDENTITY(1,1) NOT NULL,
    sport_name VARCHAR(50) NOT NULL,
    description VARCHAR(200),

    CONSTRAINT Sport_PK
        PRIMARY KEY (sport_id),

    CONSTRAINT Sport_sport_name_UN
        UNIQUE (sport_name)
);

CREATE TABLE Facility
(
    facility_id INT IDENTITY(1,1) NOT NULL,
    facility_name VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    description VARCHAR(200),
    capacity INT,
    hourly_rate DECIMAL(10,2),
    status VARCHAR(20) NOT NULL,
    Facility_Type_facility_type_id INT NOT NULL,

    CONSTRAINT Facility_PK
        PRIMARY KEY (facility_id),

    CONSTRAINT Facility_Facility_Type_FK
        FOREIGN KEY (Facility_Type_facility_type_id)
        REFERENCES Facility_Type(facility_type_id)
);

CREATE TABLE Member_Sport
(
    Sport_sport_id INT NOT NULL,
    Member_member_id INT NOT NULL,

    CONSTRAINT Member_Sport_PK
        PRIMARY KEY (Sport_sport_id, Member_member_id),

    CONSTRAINT Member_Sport_Sport_FK
        FOREIGN KEY (Sport_sport_id)
        REFERENCES Sport(sport_id),

    CONSTRAINT Member_Sport_Member_FK
        FOREIGN KEY (Member_member_id)
        REFERENCES Member(member_id)
);

CREATE TABLE Booking
(
    booking_id INT IDENTITY(1,1) NOT NULL,
    booking_date DATE NOT NULL,
    start_time TIME,
    end_time TIME,
    booking_status VARCHAR(20),
    booking_created DATETIME2,
    Member_member_id INT NOT NULL,
    Facility_facility_id INT NOT NULL,

    CONSTRAINT Booking_PK
        PRIMARY KEY (booking_id),

    CONSTRAINT Booking_Facility_FK
        FOREIGN KEY (Facility_facility_id)
        REFERENCES Facility(facility_id),

    CONSTRAINT Booking_Member_FK
        FOREIGN KEY (Member_member_id)
        REFERENCES Member(member_id),

    CONSTRAINT Booking_Status_CHK
        CHECK (booking_status IN
        ('Pending', 'Confirmed', 'Cancelled', 'Completed'))
);

CREATE TABLE Payment
(
    payment_id INT IDENTITY(1,1) NOT NULL,
    payment_date DATETIME2 NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(20) NOT NULL,
    payment_status VARCHAR(20) NOT NULL,
    transaction_reference VARCHAR(100) NOT NULL,
    Booking_booking_id INT NOT NULL,

    CONSTRAINT Payment_PK
        PRIMARY KEY (payment_id),

    CONSTRAINT Payment_transaction_reference_UN
        UNIQUE (transaction_reference),

    CONSTRAINT Payment_Booking_FK
        FOREIGN KEY (Booking_booking_id)
        REFERENCES Booking(booking_id),

    CONSTRAINT Payment_Status_CHK
        CHECK (payment_status IN
        ('Pending', 'Paid', 'Failed', 'Refunded')),

    CONSTRAINT Payment_Amount_CHK
        CHECK (amount > 0)
);

CREATE TABLE Review
(
    review_id INT IDENTITY(1,1) NOT NULL,
    rating INT NOT NULL,
    review_comment VARCHAR(200),
    review_date DATETIME2,
    Member_member_id INT NOT NULL,
    Facility_facility_id INT NOT NULL,

    CONSTRAINT Review_PK
        PRIMARY KEY (review_id),

    CONSTRAINT Review_Facility_FK
        FOREIGN KEY (Facility_facility_id)
        REFERENCES Facility(facility_id),

    CONSTRAINT Review_Member_FK
        FOREIGN KEY (Member_member_id)
        REFERENCES Member(member_id),

    CONSTRAINT Review_Rating_CHK
        CHECK (rating BETWEEN 1 AND 5)
);

CREATE TABLE Inquiry
(
    inquiry_id INT IDENTITY(1,1) NOT NULL,
    guest_name VARCHAR(100),
    guest_email VARCHAR(100),
    subject VARCHAR(100),
    message VARCHAR(500),
    inquiry_date DATETIME2,
    status VARCHAR(100),

    CONSTRAINT Inquiry_PK
        PRIMARY KEY (inquiry_id)
);

INSERT INTO Facility_Type
(type_name, description)
VALUES
('Tennis Court', 'Outdoor court suitable for tennis activities'),
('Football Ground', 'Large outdoor ground for football activities'),
('Basketball Court', 'Court suitable for basketball games'),
('Badminton Court', 'Indoor court suitable for badminton'),
('Swimming Pool', 'Community swimming facility');

INSERT INTO Member
(first_name, last_name, email, password, phone, address, city, registration_date)
VALUES
('Kasun', 'Perera', 'kasun.perera@gmail.com', 'Kasun@123',
 '0712345678', 'Temple Road', 'Colombo', '2026-09-01'),

('Nethmi', 'Fernando', 'nethmi.fernando@gmail.com', 'Nethmi@123',
 '0773456789', 'Lake Road', 'Nugegoda', '2026-09-02'),

('Tharindu', 'Bandara', 'tharindu.bandara@gmail.com', 'Tharindu@123',
 '0754567890', 'Kandy Road', 'Kandy', '2026-09-03'),

('Dinithi', 'Jayasinghe', 'dinithi.jayasinghe@gmail.com', 'Dinithi@123',
 '0765678901', 'Main Street', 'Gampaha', '2026-09-04'),

('Chamod', 'Rathnayake', 'chamod.rathnayake@gmail.com', 'Chamod@123',
 '0716789012', 'Peradeniya Road', 'Kandy', '2026-09-05'),

('Hiruni', 'Samarasinghe', 'hiruni.samarasinghe@gmail.com', 'Hiruni@123',
 '0777890123', 'Galle Road', 'Dehiwala', '2026-09-06'),

('Sahan', 'Wijesinghe', 'sahan.wijesinghe@gmail.com', 'Sahan@123',
 '0758901234', 'High Level Road', 'Maharagama', '2026-09-07'),

('Piumi', 'Karunaratne', 'piumi.karunaratne@gmail.com', 'Piumi@123',
 '0769012345', 'Flower Road', 'Colombo', '2026-09-08');

INSERT INTO Sport
(sport_name, description)
VALUES
('Cricket', 'Outdoor team sport played with a bat and ball'),
('Football', 'Team sport played using a football'),
('Tennis', 'Racket sport played on a tennis court'),
('Badminton', 'Indoor racket sport played with a shuttlecock'),
('Basketball', 'Team sport played using a basketball'),
('Swimming', 'Individual water-based sporting activity');


INSERT INTO Facility
(facility_name, location, description, capacity, hourly_rate, status, Facility_Type_facility_type_id)
VALUES
('Colombo Community Tennis Court',
 'Colombo 07',
 'Well-maintained outdoor tennis court for community members',
 4, 1500.00, 'Available', 1),

('Kandy Municipal Football Ground',
 'Kandy',
 'Large football ground suitable for community football matches',
 22, 5000.00, 'Available', 2),

('Nugegoda Basketball Arena',
 'Nugegoda',
 'Community basketball court with seating facilities',
 12, 2500.00, 'Available', 3),

('Maharagama Indoor Badminton Hall',
 'Maharagama',
 'Indoor badminton facility with multiple courts',
 8, 1200.00, 'Available', 4),

('Dehiwala Community Swimming Pool',
 'Dehiwala',
 'Community swimming pool suitable for training and recreation',
 30, 3000.00, 'Available', 5),

('Gampaha Sports Complex Tennis Court',
 'Gampaha',
 'Outdoor tennis court located inside the sports complex',
 4, 1400.00, 'Available', 1),

('Kandy Youth Basketball Court',
 'Kandy',
 'Basketball court designed for youth and community activities',
 12, 2200.00, 'Available', 3),

('Colombo Community Badminton Centre',
 'Colombo 05',
 'Indoor badminton centre with modern playing facilities',
 8, 1300.00, 'Available', 4);



 INSERT INTO Member_Sport
(Sport_sport_id, Member_member_id)
VALUES
(1, 1), -- Kasun - Cricket
(2, 1), -- Kasun - Football

(3, 2), -- Nethmi - Tennis
(4, 2), -- Nethmi - Badminton

(2, 3), -- Tharindu - Football
(5, 3), -- Tharindu - Basketball

(4, 4), -- Dinithi - Badminton
(6, 4), -- Dinithi - Swimming

(1, 5), -- Chamod - Cricket
(2, 5), -- Chamod - Football

(3, 6), -- Hiruni - Tennis
(6, 6), -- Hiruni - Swimming

(5, 7), -- Sahan - Basketball
(4, 7), -- Sahan - Badminton

(1, 8), -- Piumi - Cricket
(3, 8); -- Piumi - Tennis


INSERT INTO Booking
(booking_date, start_time, end_time, booking_status,
 booking_created, Member_member_id, Facility_facility_id)
VALUES
('2026-09-10', '08:00', '10:00', 'Confirmed',
 '2026-09-01 09:15:00', 1, 2),

('2026-09-10', '16:00', '17:00', 'Confirmed',
 '2026-09-02 10:30:00', 2, 1),

('2026-09-11', '17:00', '19:00', 'Pending',
 '2026-09-03 11:00:00', 3, 3),

('2026-09-12', '09:00', '10:00', 'Confirmed',
 '2026-09-04 08:45:00', 4, 4),

('2026-09-13', '15:00', '17:00', 'Completed',
 '2026-09-05 13:20:00', 5, 2),

('2026-09-14', '07:00', '08:00', 'Confirmed',
 '2026-09-06 07:10:00', 6, 5),

('2026-09-15', '18:00', '19:00', 'Cancelled',
 '2026-09-07 14:00:00', 7, 7),

('2026-09-16', '10:00', '11:00', 'Confirmed',
 '2026-09-08 09:40:00', 8, 8),

('2026-09-17', '16:00', '18:00', 'Pending',
 '2026-09-08 15:25:00', 1, 2),

('2026-09-18', '14:00', '15:00', 'Confirmed',
 '2026-09-08 16:10:00', 3, 7);


 INSERT INTO Payment
(payment_date, amount, payment_method, payment_status,
 transaction_reference, Booking_booking_id)
VALUES
('2026-09-01 09:20:00', 10000.00, 'Card', 'Paid',
 'PAY-SL-10001', 1),

('2026-09-02 10:35:00', 1500.00, 'Online', 'Paid',
 'PAY-SL-10002', 2),

('2026-09-03 11:05:00', 5000.00, 'Card', 'Pending',
 'PAY-SL-10003', 3),

('2026-09-04 08:50:00', 1200.00, 'Online', 'Paid',
 'PAY-SL-10004', 4),

('2026-09-05 13:25:00', 10000.00, 'Card', 'Paid',
 'PAY-SL-10005', 5),

('2026-09-06 07:15:00', 3000.00, 'Cash', 'Paid',
 'PAY-SL-10006', 6),

('2026-09-07 14:05:00', 2200.00, 'Online', 'Refunded',
 'PAY-SL-10007', 7),

('2026-09-08 09:45:00', 1300.00, 'Card', 'Paid',
 'PAY-SL-10008', 8),

('2026-09-08 15:30:00', 10000.00, 'Card', 'Failed',
 'PAY-SL-10009', 9),

('2026-09-08 16:15:00', 2200.00, 'Online', 'Paid',
 'PAY-SL-10010', 10);


INSERT INTO Review
(rating, review_comment, review_date,
 Member_member_id, Facility_facility_id)
VALUES
(5, 'The football ground was clean and spacious. Very good facility.',
 '2026-09-01 18:30:00', 1, 2),

(4, 'The tennis court was well maintained and easy to book.',
 '2026-09-02 18:00:00', 2, 1),

(5, 'The basketball court had a good surface and enough space.',
 '2026-09-03 20:00:00', 3, 3),

(4, 'The badminton hall was clean and comfortable.',
 '2026-09-04 11:00:00', 4, 4),

(5, 'The football ground was excellent for our community match.',
 '2026-09-05 18:30:00', 5, 2),

(5, 'The swimming pool was clean and the facilities were good.',
 '2026-09-06 09:30:00', 6, 5),

(4, 'The basketball court is a good place for youth training.',
 '2026-09-07 20:00:00', 7, 7);

 INSERT INTO Inquiry
(guest_name, guest_email, subject, message, inquiry_date, status)
VALUES
('Ravindu Silva',
 'ravindu.silva@gmail.com',
 'Membership Information',
 'I would like to know how to register as a member.',
 '2026-09-01 10:00:00',
 'New'),

('Sachini Perera',
 'sachini.perera@gmail.com',
 'Facility Availability',
 'Please provide information about available badminton courts.',
 '2026-09-02 11:30:00',
 'Replied'),

('Dilan Madushanka',
 'dilan.madushanka@gmail.com',
 'Football Ground Booking',
 'I would like to know the procedure for booking the football ground.',
 '2026-09-03 14:00:00',
 'New'),

('Hasini Wickramasinghe',
 'hasini.w@gmail.com',
 'Swimming Pool',
 'Please provide the swimming pool opening times and charges.',
 '2026-09-04 09:15:00',
 'Replied'),

('Ramesh Kumara',
 'ramesh.kumara@gmail.com',
 'Sports Programs',
 'Are there any community sports training programs available?',
 '2026-09-05 16:45:00',
 'New');

