﻿using Microsoft.AspNetCore.Mvc;
using Community_Sports_Facilities_Booking_System.Models;

namespace Community_Sports_Facilities_Booking_System.Controllers
{
    public class GuestController : Controller
    {
        private readonly ComSportBookingContext _context;

        public GuestController(ComSportBookingContext context)
        {
            _context = context;
        }

        public IActionResult Register()
        {
            ViewBag.Sports = _context.Sports
                .OrderBy(s => s.sport_name)
                .ToList();

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(
            string firstName,
            string lastName,
            string email,
            string password,
            string phone,
            string? address,
            string city,
            int[] selectedSports)
        {
            if (string.IsNullOrWhiteSpace(firstName) ||
                string.IsNullOrWhiteSpace(lastName) ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(phone) ||
                string.IsNullOrWhiteSpace(city))
            {
                ViewBag.Error = "Please complete all required fields.";
                return View();
            }

            bool emailExists = _context.Members
                .Any(m => m.email == email);

            if (emailExists)
            {
                ViewBag.Error = "An account with this email already exists.";
                return View();
            }

            var member = new Member
            {
                first_name = firstName,
                last_name = lastName,
                email = email,
                password = HashPassword(password),
                phone = phone,
                address = address,
                city = city,
                registration_date = DateOnly.FromDateTime(DateTime.Now)
            };

            _context.Members.Add(member);
            _context.SaveChanges();

            if (selectedSports != null && selectedSports.Length > 0)
            {
                foreach (int sportId in selectedSports)
                {
                    var memberSport = new Dictionary<string, object>
                    {
                        ["Member_member_id"] = member.member_id,
                        ["Sport_sport_id"] = sportId
                    };

                    _context.Set<Dictionary<string, object>>("Member_Sport")
                            .Add(memberSport);
                }

                _context.SaveChanges();
            }

            TempData["Success"] = "Membership registration successful. You can now sign in.";

            return RedirectToAction("Login", "Member");
        }
        private static string HashPassword(string password)
        {
            byte[] salt = System.Security.Cryptography.RandomNumberGenerator.GetBytes(16);

            byte[] hash = System.Security.Cryptography.Rfc2898DeriveBytes.Pbkdf2(
                password,
                salt,
                100000,
                System.Security.Cryptography.HashAlgorithmName.SHA256,
                32);

            return Convert.ToBase64String(salt) + "." +
                   Convert.ToBase64String(hash);
        }

        public IActionResult Search(string? location, string? facilityType)
        {
            var locations = _context.Facilities
                .Select(f => f.location)
                .Distinct()
                .OrderBy(l => l)
                .ToList();

            var facilityTypes = _context.Facility_Types
                .Select(ft => ft.type_name)
                .Distinct()
                .OrderBy(t => t)
                .ToList();

            ViewBag.Locations = locations;
            ViewBag.FacilityTypes = facilityTypes;

            var facilitiesQuery = _context.Facilities
                .Where(f => f.status == "Available")
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(location))
            {
                facilitiesQuery = facilitiesQuery
                    .Where(f => f.location == location);
            }

            if (!string.IsNullOrWhiteSpace(facilityType))
            {
                facilitiesQuery = facilitiesQuery
                    .Where(f =>
                        _context.Facility_Types.Any(ft =>
                            ft.facility_type_id == f.Facility_Type_facility_type_id &&
                            ft.type_name == facilityType));
            }

            var facilities = facilitiesQuery
                .OrderBy(f => f.facility_name)
                .ToList();

            return View(facilities);
        }
    }
}