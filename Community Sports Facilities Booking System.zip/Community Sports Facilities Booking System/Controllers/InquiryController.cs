﻿using Microsoft.AspNetCore.Mvc;
using Community_Sports_Facilities_Booking_System.Models;

namespace Community_Sports_Facilities_Booking_System.Controllers
{
    public class InquiryController : Controller
    {
        private readonly ComSportBookingContext _context;

        public InquiryController(ComSportBookingContext context)
        {
            _context = context;
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            string guestName,
            string guestEmail,
            string subject,
            string message)
        {
            if (string.IsNullOrWhiteSpace(guestName) ||
                string.IsNullOrWhiteSpace(guestEmail) ||
                string.IsNullOrWhiteSpace(subject) ||
                string.IsNullOrWhiteSpace(message))
            {
                ViewBag.Error = "Please complete all required fields.";
                return View();
            }

            var inquiry = new Inquiry
            {
                guest_name = guestName,
                guest_email = guestEmail,
                subject = subject,
                message = message,
                inquiry_date = DateTime.Now,
                status = "New"
            };

            _context.Inquiries.Add(inquiry);
            _context.SaveChanges();

            TempData["Success"] = "Your inquiry has been sent successfully.";

            return RedirectToAction("Create");
        }
    }
}