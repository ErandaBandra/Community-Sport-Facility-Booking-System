﻿using Microsoft.AspNetCore.Mvc;
using Community_Sports_Facilities_Booking_System.Models;

namespace Community_Sports_Facilities_Booking_System.Controllers
{
    public class ReviewController : Controller
    {
        private readonly ComSportBookingContext _context;

        public ReviewController(ComSportBookingContext context)
        {
            _context = context;
        }

        public IActionResult Create()
        {
            int? memberId = HttpContext.Session.GetInt32("MemberId");

            if (memberId == null)
            {
                return RedirectToAction("Login", "Member");
            }

            LoadReviewFacilities(memberId.Value);

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            int facilityId,
            int rating,
            string? reviewComment)
        {
            int? memberId = HttpContext.Session.GetInt32("MemberId");

            if (memberId == null)
            {
                return RedirectToAction("Login", "Member");
            }

            if (rating < 1 || rating > 5)
            {
                ViewBag.Error = "Rating must be between 1 and 5.";

                LoadReviewFacilities(memberId.Value);

                return View();
            }

            DateOnly today = DateOnly.FromDateTime(DateTime.Now);
            TimeOnly currentTime = TimeOnly.FromDateTime(DateTime.Now);

            bool eligibleBooking = _context.Bookings.Any(b =>
                b.Member_member_id == memberId.Value &&
                b.Facility_facility_id == facilityId &&
                b.booking_status != "Cancelled" &&
                (
                    b.booking_status == "Completed" ||
                    (
                        b.booking_status == "Confirmed" &&
                        (
                            b.booking_date < today ||
                            (
                                b.booking_date == today &&
                                b.end_time.HasValue &&
                                b.end_time.Value <= currentTime
                            )
                        )
                    )
                )
            );

            if (!eligibleBooking)
            {
                ViewBag.Error =
                    "You can only review a facility after completing your booking.";

                LoadReviewFacilities(memberId.Value);

                return View();
            }

            var review = new Review
            {
                rating = rating,
                review_comment = reviewComment,
                review_date = DateTime.Now,
                Member_member_id = memberId.Value,
                Facility_facility_id = facilityId
            };

            _context.Reviews.Add(review);
            _context.SaveChanges();

            TempData["Success"] = "Your review was submitted successfully.";

            return RedirectToAction("Create");
        }

        public IActionResult Search(int? facilityId)
        {
            var facilities = _context.Facilities
                .OrderBy(f => f.facility_name)
                .ToList();

            ViewBag.Facilities = facilities;

            var reviewsQuery = _context.Reviews
                .AsQueryable();

            if (facilityId.HasValue)
            {
                reviewsQuery = reviewsQuery
                    .Where(r => r.Facility_facility_id == facilityId.Value);
            }

            var reviews = reviewsQuery
                .OrderByDescending(r => r.review_date)
                .ToList();

            ViewBag.Members = _context.Members.ToList();

            return View(reviews);
        }

        private void LoadReviewFacilities(int memberId)
        {
            DateOnly today = DateOnly.FromDateTime(DateTime.Now);
            TimeOnly currentTime = TimeOnly.FromDateTime(DateTime.Now);

            var eligibleFacilityIds = _context.Bookings
                .Where(b =>
                    b.Member_member_id == memberId &&
                    b.booking_status != "Cancelled" &&
                    (
                        b.booking_status == "Completed" ||
                        (
                            b.booking_status == "Confirmed" &&
                            (
                                b.booking_date < today ||
                                (
                                    b.booking_date == today &&
                                    b.end_time.HasValue &&
                                    b.end_time.Value <= currentTime
                                )
                            )
                        )
                    )
                )
                .Select(b => b.Facility_facility_id)
                .Distinct()
                .ToList();

            ViewBag.Facilities = _context.Facilities
                .Where(f => eligibleFacilityIds.Contains(f.facility_id))
                .OrderBy(f => f.facility_name)
                .ToList();
        }
    }
}