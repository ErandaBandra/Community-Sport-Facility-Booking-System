﻿using Microsoft.AspNetCore.Mvc;
using Community_Sports_Facilities_Booking_System.Models;

namespace Community_Sports_Facilities_Booking_System.Controllers
{
    public class PaymentController : Controller
    {
        private readonly ComSportBookingContext _context;

        public PaymentController(ComSportBookingContext context)
        {
            _context = context;
        }

        public IActionResult Create(int bookingId)
        {
            var booking = _context.Bookings
                .FirstOrDefault(b => b.booking_id == bookingId);

            if (booking == null)
            {
                return NotFound();
            }

            var facility = _context.Facilities
                .FirstOrDefault(f => f.facility_id == booking.Facility_facility_id);

            if (facility == null)
            {
                return NotFound();
            }

            ViewBag.Facility = facility;

            return View(booking);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Process(int bookingId, string paymentMethod)
        {
            var booking = _context.Bookings
                .FirstOrDefault(b => b.booking_id == bookingId);

            if (booking == null)
            {
                return NotFound();
            }

            if (string.IsNullOrWhiteSpace(paymentMethod))
            {
                return RedirectToAction("Create", new { bookingId });
            }

            var facility = _context.Facilities
                .FirstOrDefault(f => f.facility_id == booking.Facility_facility_id);

            if (facility == null)
            {
                return NotFound();
            }

            if (!booking.start_time.HasValue || !booking.end_time.HasValue)
            {
                return BadRequest("Booking time information is missing.");
            }

            double duration = (booking.end_time.Value - booking.start_time.Value).TotalHours;

            decimal amount = (decimal)duration * (facility.hourly_rate ?? 0);

            var payment = new Payment
            {
                payment_date = DateTime.Now,
                amount = amount,
                payment_method = paymentMethod,
                payment_status = "Paid",
                transaction_reference = "PAY-SL-" + DateTime.Now.ToString("yyyyMMddHHmmss"),
                Booking_booking_id = booking.booking_id
            };

            _context.Payments.Add(payment);

            booking.booking_status = "Confirmed";

            _context.SaveChanges();

            return RedirectToAction("Success", new { paymentId = payment.payment_id });
        }

        public IActionResult Success(int paymentId)
        {
            var payment = _context.Payments
                .FirstOrDefault(p => p.payment_id == paymentId);

            if (payment == null)
            {
                return NotFound();
            }

            var booking = _context.Bookings
                .FirstOrDefault(b => b.booking_id == payment.Booking_booking_id);

            if (booking == null)
            {
                return NotFound();
            }

            var facility = _context.Facilities
                .FirstOrDefault(f => f.facility_id == booking.Facility_facility_id);

            if (facility == null)
            {
                return NotFound();
            }

            ViewBag.Booking = booking;
            ViewBag.Facility = facility;

            return View(payment);
        }
    }
}