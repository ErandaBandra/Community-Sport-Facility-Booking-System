﻿using Community_Sports_Facilities_Booking_System.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;

namespace Community_Sports_Facilities_Booking_System.Controllers
{
    public class MemberController : Controller
    {
        private readonly ComSportBookingContext _context;

        public MemberController(ComSportBookingContext context)
        {
            _context = context;
        }

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(string email, string password)
        {
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                ViewBag.Error = "Please enter your email and password.";
                return View();
            }

            var member = _context.Members
                .FirstOrDefault(m => m.email == email);

            if (member == null)
            {
                ViewBag.Error = "Invalid email or password.";
                return View();
            }

            bool passwordValid = VerifyPassword(password, member.password);

            if (!passwordValid)
            {
                ViewBag.Error = "Invalid email or password.";
                return View();
            }

            HttpContext.Session.SetInt32("MemberId", member.member_id);
            HttpContext.Session.SetString("MemberName", member.first_name);

            TempData["Success"] = "Login successful. Welcome " + member.first_name;

            return RedirectToAction("Index", "Home");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            TempData["Success"] = "You have been logged out successfully.";

            return RedirectToAction("Index", "Home");
        }


        public IActionResult Register()
        {
            LoadSports();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(
            string firstName,
            string lastName,
            string email,
            string password,
            string phone,
            string address,
            string city,
            int[] selectedSports)
        {
            if (string.IsNullOrWhiteSpace(firstName) ||
                string.IsNullOrWhiteSpace(lastName) ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(phone) ||
                string.IsNullOrWhiteSpace(city))
            {
                ViewBag.Error = "Please fill in all required fields.";
                LoadSports();
                return View();
            }

            if (_context.Members.Any(m => m.email == email))
            {
                ViewBag.Error = "An account with this email already exists.";
                LoadSports();
                return View();
            }

            string passwordHash = HashPassword(password);

  

        var member = new Member

            {
                first_name = firstName,
                last_name = lastName,
                email = email,
                password = passwordHash,
                phone = phone,
                address = address,
                city = city,
                registration_date = DateOnly.FromDateTime(DateTime.Now)
            };

            _context.Members.Add(member);
            _context.SaveChanges();

            if (selectedSports != null && selectedSports.Length > 0)
            {
                foreach (int sportId in selectedSports)
                {
                    var memberSport = new Dictionary<string, object>
                    {
                        ["Member_member_id"] = member.member_id,
                        ["Sport_sport_id"] = sportId
                    };

                    _context.Set<Dictionary<string, object>>("Member_Sport")
                            .Add(memberSport);
                }

                _context.SaveChanges();
            }

            TempData["Success"] = "Registration successful. You can now sign in.";

            return RedirectToAction("Login");
        }
        private void LoadSports()
        {
            ViewBag.Sports = _context.Sports
                .OrderBy(s => s.sport_name)
                .ToList();
        }

        private static string HashPassword(string password)
        {
            byte[] salt = RandomNumberGenerator.GetBytes(16);

            byte[] hash = Rfc2898DeriveBytes.Pbkdf2(
                password,
                salt,
                100000,
                HashAlgorithmName.SHA256,
                32);

            return Convert.ToBase64String(salt) + "." +
                   Convert.ToBase64String(hash);
        }
        private static bool VerifyPassword(string password, string storedHash)
        {
            try
            {
                string[] parts = storedHash.Split('.');

                if (parts.Length != 2)
                    return false;

                byte[] salt = Convert.FromBase64String(parts[0]);
                byte[] storedPasswordHash = Convert.FromBase64String(parts[1]);

                using var pbkdf2 = new System.Security.Cryptography.Rfc2898DeriveBytes(
                    password,
                    salt,
                    100000,
                    System.Security.Cryptography.HashAlgorithmName.SHA256
                );

                byte[] passwordHash = pbkdf2.GetBytes(32);

                return System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(
                    passwordHash,
                    storedPasswordHash
                );
            }
            catch
            {
                return false;
            }
        }
    }
}