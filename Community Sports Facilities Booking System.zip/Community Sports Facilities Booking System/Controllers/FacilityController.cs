﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Community_Sports_Facilities_Booking_System.Models;

namespace Community_Sports_Facilities_Booking_System.Controllers
{
    public class FacilityController : Controller
    {
        private readonly ComSportBookingContext _context;

        public FacilityController(ComSportBookingContext context)
        {
            _context = context;
        }

        public IActionResult Search()
        {
            ViewBag.FacilityTypes = _context.Facility_Types
                .OrderBy(f => f.type_name)
                .ToList();

            ViewBag.Locations = _context.Facilities
                .Select(f => f.location)
                .Distinct()
                .OrderBy(l => l)
                .ToList();

            ViewBag.FacilityTypes = _context.Facility_Types
                 .OrderBy(f => f.type_name)
                 .ToList();

            ViewBag.Locations = _context.Facilities
                .Select(f => f.location)
                .Distinct()
                .OrderBy(l => l)
                .ToList();

            ViewBag.IsMember = HttpContext.Session.GetInt32("MemberId") != null;

            return View(new FacilitySearchViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Search(FacilitySearchViewModel model)
        {
            ViewBag.FacilityTypes = _context.Facility_Types
                .OrderBy(f => f.type_name)
                 .ToList();

            ViewBag.Locations = _context.Facilities
                .Select(f => f.location)
                .Distinct()
                .OrderBy(l => l)
                .ToList();

            var query = _context.Facilities
                .AsQueryable();

            if (model.FacilityTypeId.HasValue)
            {
                query = query.Where(f =>
                    f.Facility_Type_facility_type_id == model.FacilityTypeId.Value);
            }

            if (!string.IsNullOrWhiteSpace(model.Location))
            {
                query = query.Where(f =>
                    f.location.Contains(model.Location));
            }

            query = query.Where(f => f.status == "Available");

            if (model.BookingDate.HasValue &&
                model.StartTime.HasValue &&
                model.EndTime.HasValue)
            {
                var bookingDate = model.BookingDate.Value;
                var requestedStart = model.StartTime.Value;
                var requestedEnd = model.EndTime.Value;

                query = query.Where(f =>
                    !_context.Bookings.Any(b =>
                        b.Facility_facility_id == f.facility_id &&
                        b.booking_date == bookingDate &&
                        (b.booking_status == "Pending" ||
                         b.booking_status == "Confirmed") &&
                        b.start_time < requestedEnd &&
                        b.end_time > requestedStart
                    ));
            }

            model.Results = query
                .OrderBy(f => f.facility_name)
                .ToList();

            return View(model);
        }
    }
}