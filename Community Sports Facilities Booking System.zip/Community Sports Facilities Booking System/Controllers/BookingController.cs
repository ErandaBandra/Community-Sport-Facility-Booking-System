﻿using Microsoft.AspNetCore.Mvc;
using Community_Sports_Facilities_Booking_System.Models;

namespace Community_Sports_Facilities_Booking_System.Controllers
{
    public class BookingController : Controller
    {
        private readonly ComSportBookingContext _context;

        public BookingController(ComSportBookingContext context)
        {
            _context = context;
        }

        public IActionResult Create(int facilityId)
        {
            var facility = _context.Facilities
                .FirstOrDefault(f => f.facility_id == facilityId);

            if (facility == null)
            {
                return NotFound();
            }

            ViewBag.Facility = facility;

            return View();
        }

        // POST: Booking/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(
            int facilityId,
            DateOnly bookingDate,
            TimeOnly startTime,
            TimeOnly endTime)
        {
            if (endTime <= startTime)
            {
                ViewBag.Error = "End time must be later than start time.";

                var facility = _context.Facilities
                    .FirstOrDefault(f => f.facility_id == facilityId);

                ViewBag.Facility = facility;

                return View();
            }

            var selectedFacility = _context.Facilities
                .FirstOrDefault(f => f.facility_id == facilityId);

            if (selectedFacility == null)
            {
                return NotFound();
            }

            bool alreadyBooked = _context.Bookings.Any(b =>
                b.Facility_facility_id == facilityId &&
                b.booking_date == bookingDate &&
                (b.booking_status == "Pending" ||
                 b.booking_status == "Confirmed") &&
                b.start_time < endTime &&
                b.end_time > startTime
            );

            if (alreadyBooked)
            {
                ViewBag.Error = "This facility is already booked for the selected time.";

                ViewBag.Facility = selectedFacility;

                return View();
            }

            int? memberId = HttpContext.Session.GetInt32("MemberId");

            if (memberId == null)
            {
                return RedirectToAction("Login", "Member");
            }

            var booking = new Booking
            {
                booking_date = bookingDate,
                start_time = startTime,
                end_time = endTime,
                booking_status = "Pending",
                booking_created = DateTime.Now,
                Member_member_id = memberId.Value,
                Facility_facility_id = facilityId
            };

            _context.Bookings.Add(booking);
            _context.SaveChanges();

            return RedirectToAction("Create", "Payment", new { bookingId = booking.booking_id });
        }
        public IActionResult MyBookings()
        {
            int? memberId = HttpContext.Session.GetInt32("MemberId");

            if (memberId == null)
            {
                return RedirectToAction("Login", "Member");
            }

            var bookings = _context.Bookings
                .Where(b => b.Member_member_id == memberId.Value)
                .OrderByDescending(b => b.booking_date)
                .ThenByDescending(b => b.start_time)
                .ToList();

            ViewBag.Facilities = _context.Facilities
                .ToDictionary(f => f.facility_id, f => f);

            ViewBag.Payments = _context.Payments
                .ToList();

            return View(bookings);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Cancel(int bookingId)
        {
            int? memberId = HttpContext.Session.GetInt32("MemberId");

            if (memberId == null)
            {
                return RedirectToAction("Login", "Member");
            }

            var booking = _context.Bookings
                .FirstOrDefault(b =>
                    b.booking_id == bookingId &&
                    b.Member_member_id == memberId.Value);

            if (booking == null)
            {
                return NotFound();
            }

            if (booking.booking_status == "Completed")
            {
                TempData["Error"] = "Completed bookings cannot be cancelled.";
                return RedirectToAction("MyBookings");
            }

            if (booking.booking_status == "Cancelled")
            {
                TempData["Error"] = "This booking has already been cancelled.";
                return RedirectToAction("MyBookings");
            }

            booking.booking_status = "Cancelled";

            _context.SaveChanges();

            TempData["Success"] = "Your booking has been cancelled successfully.";

            return RedirectToAction("MyBookings");
        }
    }
}