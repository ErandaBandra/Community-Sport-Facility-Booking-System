﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Community_Sports_Facilities_Booking_System.Models;

[Table("Facility")]
public partial class Facility
{
    [Key]
    public int facility_id { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string facility_name { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string location { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string? description { get; set; }

    public int? capacity { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal? hourly_rate { get; set; }

    [StringLength(20)]
    [Unicode(false)]
    public string status { get; set; } = null!;

    public int Facility_Type_facility_type_id { get; set; }

    [InverseProperty("Facility_facility")]
    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

    [ForeignKey("Facility_Type_facility_type_id")]
    [InverseProperty("Facilities")]
    public virtual Facility_Type Facility_Type_facility_type { get; set; } = null!;

    [InverseProperty("Facility_facility")]
    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();
}
