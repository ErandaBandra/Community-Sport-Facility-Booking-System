﻿using System;
using System.Collections.Generic;

namespace Community_Sports_Facilities_Booking_System.Models
{
    public class FacilitySearchViewModel
    {
        public int? FacilityTypeId { get; set; }

        public string? Location { get; set; }

        public DateOnly? BookingDate { get; set; }

        public TimeOnly? StartTime { get; set; }

        public TimeOnly? EndTime { get; set; }

        public List<Facility> Results { get; set; } = new List<Facility>();
    }
}
