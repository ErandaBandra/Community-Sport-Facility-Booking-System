﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Community_Sports_Facilities_Booking_System.Models;

[Table("Payment")]
[Index("transaction_reference", Name = "Payment_transaction_reference_UN", IsUnique = true)]
public partial class Payment
{
    [Key]
    public int payment_id { get; set; }

    public DateTime payment_date { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal amount { get; set; }

    [StringLength(20)]
    [Unicode(false)]
    public string payment_method { get; set; } = null!;

    [StringLength(20)]
    [Unicode(false)]
    public string payment_status { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string transaction_reference { get; set; } = null!;

    public int Booking_booking_id { get; set; }

    [ForeignKey("Booking_booking_id")]
    [InverseProperty("Payments")]
    public virtual Booking Booking_booking { get; set; } = null!;
}
