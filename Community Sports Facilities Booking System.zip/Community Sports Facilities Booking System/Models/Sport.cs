﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Community_Sports_Facilities_Booking_System.Models;

[Table("Sport")]
[Index("sport_name", Name = "Sport_sport_name_UN", IsUnique = true)]
public partial class Sport
{
    [Key]
    public int sport_id { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string sport_name { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string? description { get; set; }

    [ForeignKey("Sport_sport_id")]
    [InverseProperty("Sport_sports")]
    public virtual ICollection<Member> Member_members { get; set; } = new List<Member>();
}
