﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Community_Sports_Facilities_Booking_System.Models;

[Table("Member")]
[Index("email", Name = "Member_email_UN", IsUnique = true)]
public partial class Member
{
    [Key]
    public int member_id { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string first_name { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string last_name { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string email { get; set; } = null!;

    [StringLength(255)]
    [Unicode(false)]
    public string password { get; set; } = null!;

    [StringLength(10)]
    [Unicode(false)]
    public string phone { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string? address { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string city { get; set; } = null!;

    public DateOnly registration_date { get; set; }

    [InverseProperty("Member_member")]
    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

    [InverseProperty("Member_member")]
    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();

    [ForeignKey("Member_member_id")]
    [InverseProperty("Member_members")]
    public virtual ICollection<Sport> Sport_sports { get; set; } = new List<Sport>();
}
