﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Community_Sports_Facilities_Booking_System.Models;

[Table("Booking")]
public partial class Booking
{
    [Key]
    public int booking_id { get; set; }

    public DateOnly booking_date { get; set; }

    public TimeOnly? start_time { get; set; }

    public TimeOnly? end_time { get; set; }

    [StringLength(20)]
    [Unicode(false)]
    public string? booking_status { get; set; }

    public DateTime? booking_created { get; set; }

    public int Member_member_id { get; set; }

    public int Facility_facility_id { get; set; }

    [ForeignKey("Facility_facility_id")]
    [InverseProperty("Bookings")]
    public virtual Facility Facility_facility { get; set; } = null!;

    [ForeignKey("Member_member_id")]
    [InverseProperty("Bookings")]
    public virtual Member Member_member { get; set; } = null!;

    [InverseProperty("Booking_booking")]
    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();
}
