﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Community_Sports_Facilities_Booking_System.Models;

[Table("Review")]
public partial class Review
{
    [Key]
    public int review_id { get; set; }

    public int rating { get; set; }

    [StringLength(200)]
    [Unicode(false)]
    public string? review_comment { get; set; }

    public DateTime? review_date { get; set; }

    public int Member_member_id { get; set; }

    public int Facility_facility_id { get; set; }

    [ForeignKey("Facility_facility_id")]
    [InverseProperty("Reviews")]
    public virtual Facility Facility_facility { get; set; } = null!;

    [ForeignKey("Member_member_id")]
    [InverseProperty("Reviews")]
    public virtual Member Member_member { get; set; } = null!;
}
