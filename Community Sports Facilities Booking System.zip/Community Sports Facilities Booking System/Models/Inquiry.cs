﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Community_Sports_Facilities_Booking_System.Models;

[Table("Inquiry")]
public partial class Inquiry
{
    [Key]
    public int inquiry_id { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string? guest_name { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string? guest_email { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string? subject { get; set; }

    [StringLength(500)]
    [Unicode(false)]
    public string? message { get; set; }

    public DateTime? inquiry_date { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string? status { get; set; }
}
