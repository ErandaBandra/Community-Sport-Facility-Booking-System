﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Community_Sports_Facilities_Booking_System.Models;

[Table("Facility_Type")]
[Index("type_name", Name = "Facility_Type_type_name_UN", IsUnique = true)]
public partial class Facility_Type
{
    [Key]
    public int facility_type_id { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string type_name { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string? description { get; set; }

    [InverseProperty("Facility_Type_facility_type")]
    public virtual ICollection<Facility> Facilities { get; set; } = new List<Facility>();
}
