﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Community_Sports_Facilities_Booking_System.Models;

public partial class ComSportBookingContext : DbContext
{
    public ComSportBookingContext()
    {
    }

    public ComSportBookingContext(DbContextOptions<ComSportBookingContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Booking> Bookings { get; set; }

    public virtual DbSet<Facility> Facilities { get; set; }

    public virtual DbSet<Facility_Type> Facility_Types { get; set; }

    public virtual DbSet<Inquiry> Inquiries { get; set; }

    public virtual DbSet<Member> Members { get; set; }

    public virtual DbSet<Payment> Payments { get; set; }

    public virtual DbSet<Review> Reviews { get; set; }

    public virtual DbSet<Sport> Sports { get; set; }

    protected override void OnConfiguring(Microsoft.EntityFrameworkCore.DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=DESKTOP-PDVKE2I\\SQLEXPRESS;Database=ComSportBooking;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Booking>(entity =>
        {
            entity.HasKey(e => e.booking_id).HasName("Booking_PK");

            entity.HasOne(d => d.Facility_facility).WithMany(p => p.Bookings)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("Booking_Facility_FK");

            entity.HasOne(d => d.Member_member).WithMany(p => p.Bookings)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("Booking_Member_FK");
        });

        modelBuilder.Entity<Facility>(entity =>
        {
            entity.HasKey(e => e.facility_id).HasName("Facility_PK");

            entity.HasOne(d => d.Facility_Type_facility_type).WithMany(p => p.Facilities)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("Facility_Facility_Type_FK");
        });

        modelBuilder.Entity<Facility_Type>(entity =>
        {
            entity.HasKey(e => e.facility_type_id).HasName("Facility_Type_PK");
        });

        modelBuilder.Entity<Inquiry>(entity =>
        {
            entity.HasKey(e => e.inquiry_id).HasName("Inquiry_PK");
        });

        modelBuilder.Entity<Member>(entity =>
        {
            entity.HasKey(e => e.member_id).HasName("Member_PK");
        });

        modelBuilder.Entity<Payment>(entity =>
        {
            entity.HasKey(e => e.payment_id).HasName("Payment_PK");

            entity.HasOne(d => d.Booking_booking).WithMany(p => p.Payments)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("Payment_Booking_FK");
        });

        modelBuilder.Entity<Review>(entity =>
        {
            entity.HasKey(e => e.review_id).HasName("Review_PK");

            entity.HasOne(d => d.Facility_facility).WithMany(p => p.Reviews)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("Review_Facility_FK");

            entity.HasOne(d => d.Member_member).WithMany(p => p.Reviews)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("Review_Member_FK");
        });

        modelBuilder.Entity<Sport>(entity =>
        {
            entity.HasKey(e => e.sport_id).HasName("Sport_PK");

            entity.HasMany(d => d.Member_members).WithMany(p => p.Sport_sports)
                .UsingEntity<Dictionary<string, object>>(
                    "Member_Sport",
                    r => r.HasOne<Member>().WithMany()
                        .HasForeignKey("Member_member_id")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("Member_Sport_Member_FK"),
                    l => l.HasOne<Sport>().WithMany()
                        .HasForeignKey("Sport_sport_id")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("Member_Sport_Sport_FK"),
                    j =>
                    {
                        j.HasKey("Sport_sport_id", "Member_member_id").HasName("Member_Sport_PK");
                        j.ToTable("Member_Sport");
                    });
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
